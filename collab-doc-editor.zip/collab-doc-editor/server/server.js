const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
app.use(cors());
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "http://localhost:3000", methods: ["GET", "POST"] }
});

const documents = {};

io.on("connection", (socket) => {
  console.log("🟢 A client connected");

  socket.on("get-document", (docId) => {
    if (!documents[docId]) {
      documents[docId] = "";
    }
    socket.join(docId);
    socket.emit("load-document", documents[docId]);

    socket.on("send-changes", delta => {
      socket.broadcast.to(docId).emit("receive-changes", delta);
    });

    socket.on("save-document", data => {
      documents[docId] = data;
    });
  });
});

server.listen(5000, () => {
  console.log("✅ Server is running WITHOUT MongoDB on http://localhost:5000");
});